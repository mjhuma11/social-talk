<?php
if (!defined('SITE_URL')) {
    define('SITE_URL', 'http://localhost/round64/social-talk1/social-talk/');
}
if (!defined('logo_PATH')) {
    define('loho_PATH', SITE_URL . '/assets/logo/');
}
if (!defined('CSS_PATH')) {
    define('CSS_PATH', SITE_URL . '/assets/css/');
}
if (!defined('JS_PATH')) {
    define('JS_PATH', SITE_URL . '/assets/js/');
}

?>